package com.company.PracticaInterfaces;

public interface Luchar {
    public default void luchar(){
        System.out.println("Voy a pelear");
    }
}
