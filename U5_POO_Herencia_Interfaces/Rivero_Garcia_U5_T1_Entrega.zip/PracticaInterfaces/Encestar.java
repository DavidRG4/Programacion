package com.company.PracticaInterfaces;

public interface Encestar {
    public default void encestar(){
        System.out.println("2 Puntos!!!!!!");
    }
}
