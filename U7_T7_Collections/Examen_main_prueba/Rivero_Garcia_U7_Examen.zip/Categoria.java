package com.company;

public enum Categoria {
    SENIOR,JUNIOR,VETERANO
}
