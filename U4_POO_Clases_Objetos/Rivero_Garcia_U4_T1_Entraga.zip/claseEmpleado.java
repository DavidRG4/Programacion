package com.company;

public enum claseEmpleado {
    administrativo,
    tecnico,
    directivo
}
